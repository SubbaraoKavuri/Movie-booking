﻿// Complete Home.js with all features
const contentData = {
    "new-releases": [
        {
            id: "Junior",
            title: "Junior",
            image: "https://assets-in.bmscdn.com/iedb/movies/images/mobile/thumbnail/xlarge/junior-et00448284-1753078569.jpg",
            
            year: "2025",
            type: "Movie",
            new: true
        },
        {
            id: "F1: The Movie",
            title: "F1: The Movie",
            image: "https://assets-in.bmscdn.com/iedb/movies/images/mobile/thumbnail/xlarge/f1-the-movie-et00403839-1750674185.jpg",
            
            year: "2025",
            type: "Movie",
            new: true
        },
        {
            id:"Superman",
            title: "Superman",
            image: "https://assets-in.bmscdn.com/iedb/movies/images/mobile/thumbnail/xlarge/superman-et00397464-1747201574.jpg",
            
            year: "2025",
            type: "Movie",
            new: true
        },
        {
            id: "Jurassic World: Rebirth",
            title: "Jurassic World: Rebirth",
            image: "https://assets-in.bmscdn.com/iedb/movies/images/mobile/thumbnail/xlarge/jurassic-world-rebirth-et00432498-1747899467.jpg",
           
            year: "2025",
            type: "Movie",
            new: true
        },
        {
            id: "Saiyaara",
            title: "Saiyaara",
            image: "https://assets-in.bmscdn.com/iedb/movies/images/mobile/thumbnail/xlarge/saiyaara-et00447951-1752737895.jpg",
            
            year: "2025",
            type: "Movie",
            new: true
        },
        {
            id: "How to Train Your Dragon",
            title: "How to Train Your Dragon",
            image: "https://assets-in.bmscdn.com/iedb/movies/images/extra/vertical_logo/mobile/thumbnail/xxlarge/how-to-train-your-dragon-et00420723-1752838835.jpg",
            
            year: "2025",
            type: "Movie",
            new: true
        }
    ],
    "ott-recommendations": [
        {
            id: "StrangerThings",
            title: "Stranger Things",
            image: "https://i.pinimg.com/736x/a2/92/45/a29245a067f4235db14582353f2e4d1b.jpg",
            
            year: "2025",
            type: "Series",
            platform: "Netflix"
        },
        {
            id: "TheLastofUs",
            title: "The Last of Us",
            image: "https://static1.srcdn.com/wordpress/wp-content/uploads/2025/03/snapinst-app_485921070_18123331294522187_2660669886606584076_n_1080.jpg",
            
            year: "2025",
            type: "Series",
            platform: "HBO"
        },
        {
            id: "IronHeart",
            title: "Iron Heart",
            image: "https://preview.redd.it/new-poster-for-ironheart-v0-6jbkye8k3daf1.png?auto=webp&s=f73662a7c014ad05a5ffded2be5153f93f3277be",
            
            year: "2025",
            type: "Series",
            platform: "Disney+"
        },
        {
            id: "Money Heist",
            title: "Money Heist",
            image: "https://image.tmdb.org/t/p/original/reEMJA1uzscCbkpeRJeTT2bjqUp.jpg",
            
            year: "2021",
            type: "Series",
            platform: "Disney+"
        },
        {
            id: "Loki",
            title: "Loki",
            image: "https://i.pinimg.com/736x/65/a6/4a/65a64a361b97200e3f5c71d54b5d516a.jpg",
            
            year: "2023",
            type: "Series",
            platform: "Disney+"
        }
    ],
    "new-songs": [
        {
            title: "Anna Antene - Kingdom",
            image: "https://c.saavncdn.com/096/Kingdom-Telugu-2025-20250717114301-500x500.jpg",
            video: "https://youtu.be/q76ue-byDzY?si=4r2-agPEKEfNAMyj",
            year: "2025",
            type: "Song",
            new: true
        },
        {
            title: "Nadhive - The Girlfriend",
            image: "https://c.saavncdn.com/169/Nadhive-From-The-Girlfriend-Telugu-2025-20250716131014-500x500.jpg",
            video: "https://youtu.be/W9qw2_JuWQ4?si=3UQgZdhrKxMqRcNW",
            year: "2025",
            type: "Song",
            new: true
        },
        {
            title: "Nuvvunte Chaley - Andhra King Taluka",
            image: "https://c.saavncdn.com/534/Nuvvunte-Chaley-From-Andhra-King-Taluka-Telugu-2025-20250717181004-500x500.jpg",
            video: "https://youtu.be/s9NBDKfVg1c?si=jPD4NmoZwBANUxn1",
            year: "2025",
            type: "Song",
            new: true
        },
        {
            title: "Monica - Coolie",
            image: "https://c.saavncdn.com/490/Monica-From-Coolie-Telugu-Telugu-2025-20250711092828-500x500.jpg",
            video: "https://youtu.be/2qCpY38ompo?si=yJskmXgD0bDya2Cn",
            year: "2025",
            type: "Song",
            new: true
        },
        {
            title: "Evaradi Evaradi - Hari Hara Veera Mallu",
            image: "https://c.saavncdn.com/936/Evaradi-Evaradi-From-Hari-Hara-Veera-Mallu-Telugu-Telugu-2025-20250709184638-500x500.jpg",
            video: "https://youtu.be/FpEMnlKXAoY?si=gpkigjLUUj8-Q1eT",
            year: "2025",
            type: "Song",
            new: true
        }
    ],
    "trending-songs": [
        {
            title: "Sarkaru Raa - Daaku Maharaaj",
            image: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcS8ITu0qqi0ZFhYa78HhCMRhFo01ckb-mscbg&s",
            video: "https://youtu.be/YB4U_RpbuQQ?si=lqLz6AnS-surJyir",
            year: "2025",
            type: "Song",
            trending: true
        },
        {
            title: "Hridayam Lopala - Kingdom",
            image: "https://preview.redd.it/kingdom-new-poster-v0-veuu14aujpze1.jpeg?auto=webp&s=8b058bcf3943e79858732b9712e4812499b60bab",
            video: "https://youtu.be/iNxITn78e-0?si=Tm3CEhjtKRVcN9X2",
            year: "2025",
            type: "Song",
            trending: true
        },
        {
            title: "Poyiraa Mama - Kuberaa",
            image: "https://www.indianewsstream.com/wp-content/uploads/2024/04/202404163147944.png",
            video: "https://youtu.be/TIAI36faO84?si=rPbzzaW0GIL_rjbU",
            year: "2025",
            type: "Song",
            trending: true
        },
        {
            title: "Viral Vayyari - Junior",
            image: "https://assets-in.bmscdn.com/iedb/movies/images/mobile/thumbnail/xlarge/junior-et00448284-1753078569.jpg",
            video: "https://youtu.be/NsUqPzdkFTY?si=d4YPi59wsZlA6XtH",
            year: "2025",
            type: "Song",
            trending: true
        },
        {
            title: "Prema Velluva - Hit - 3",
            image: "https://imgs.search.brave.com/RRTDBz4ffRCOQXQA-ko0kOUToyL7jZBvXZbvEbYliHU/rs:fit:860:0:0:0/g:ce/aHR0cHM6Ly9pLnJl/ZGQuaXQvZG83c3E0/dGRxdHBlMS5wbmc",
            video: "https://youtu.be/rslYbT2GvRs?si=KCVfjZokdpVd5L1b",
            year: "2025",
            type: "Song",
            trending: true
        }
    ],
    "upcoming-movies": [
        {
            id: "hari-hara-veera-mallu",
            title: "Hari Hara Veera Mallu - Part 1 Sword vs Spirit",
            image: "https://assets-in.bmscdn.com/iedb/movies/images/mobile/thumbnail/xlarge/hari-hara-veera-mallu--part-1-sword-vs-spirit-et00308207-1751530343.jpg",
           
            year: "24 Jul, 2025",
            type: "Movie",
            upcoming: true
        },
        {
            id: "Avatar: Fire and Ash", 
            title: "Avatar: Fire and Ash",
            image: "https://assets-in.bmscdn.com/iedb/movies/images/mobile/thumbnail/xlarge/avatar-fire-and-ash-et00407893-1723442554.jpg",
            
            year: "19 Dec, 2025",
            type: "Movie",
            upcoming: true
        },
        {
            id: "The Fantastic Four: First Steps",
            title: "The Fantastic Four: First Steps",
            image: "https://assets-in.bmscdn.com/iedb/movies/images/mobile/thumbnail/xlarge/the-fantastic-four-first-steps-et00432123-1751280571.jpg",
           
            year: "25 Jul, 2025",
            type: "Movie",
            upcoming: true
        },
        {
            id: "Mahavatar Narsimha",
            title: "Mahavatar Narsimha",
            image: "https://assets-in.bmscdn.com/iedb/movies/images/mobile/thumbnail/xlarge/mahavatar-narsimha-et00429289-1736935955.jpg",
           
            year: "25 Jul, 2025",
            type: "Movie",
            upcoming: true
        },
        {
            id: "War 2",
            title: "War 2",
            image: "https://assets-in.bmscdn.com/iedb/movies/images/mobile/thumbnail/xlarge/war-2-et00356501-1752669782.jpg",
            
            year: "14 Aug, 2025",
            type: "Movie",
            upcoming: true
        },
        {
            id: "Coolie",
            title: "Coolie",
            image: "https://assets-in.bmscdn.com/iedb/movies/images/mobile/thumbnail/xlarge/coolie-et00395817-1713790691.jpg",
            video: "https://www.youtube.com/embed/VIDEO_ID_COOLIE",
            year: "14 Aug, 2025",
            type: "Movie",
            upcoming: true
        }
    ]
};

// Notification data
const notifications = [
    { title: "New Release", content: "Junior is now available for streaming!" },
    { title: "Recommendation", content: "Based on your history, we recommend 'F1: The Movie'" },
    { title: "New Song", content: "Anna Antene from Kingdom is trending now!" },
    { title: "Upcoming", content: "Hari Hara Veera Mallu coming next month - Watch trailer now" }
];

// YouTube ID extractor
function getYouTubeId(url) {
    if (!url) return null;
    if (url.includes('embed/')) return url.split('embed/')[1].split('?')[0];
    if (url.includes('youtu.be/')) return url.split('youtu.be/')[1].split('?')[0];
    if (url.includes('v=')) return url.split('v=')[1].split('&')[0];
    return null;
}

function createContentCard(item, sectionId) {
    const card = document.createElement('div');
    card.className = 'content-card';
    card.innerHTML = `
        ${item.new ? '<span class="card-badge">NEW</span>' : ''}
        ${item.trending ? '<span class="card-badge">TRENDING</span>' : ''}
        ${item.upcoming ? '<span class="card-badge">COMING SOON</span>' : ''}
        <img src="${item.image}" alt="${item.title}" loading="lazy">
        <div class="card-info">
            <h3 class="card-title">${item.title}</h3>
            <div class="card-meta">
                <span>${item.year}</span>
                <span>${item.type}</span>
                ${item.platform ? `<span class="platform">${item.platform}</span>` : ''}
            </div>
        </div>
        <div class="video-preview"></div>
    `;

    // Click handler for movie cards - redirect to detail pages
    // Click handler for movie cards - redirect to detail pages
    if (sectionId === 'new-releases' || sectionId === 'ott-recommendations' || sectionId === 'upcoming-movies') {
        card.addEventListener('click', (e) => {
            if (e.target.classList.contains('card-badge')) return;

            // Redirect based on item ID
            if (item.id === 'F1: The Movie') {
                window.location.href = '/Home/F1TheMovie';
            } else if (item.id === 'Junior') {
                window.location.href = '/Home/Junior2025';
            } else if (item.id === 'Superman') {
                window.location.href = '/Home/Superman';
            } else if (item.id === 'Jurassic World: Rebirth') {
                window.location.href = '/Home/JurassicWorldRebirth';
            } else if (item.id === 'Saiyaara') {
                window.location.href = '/Home/Saiyaara';
            } else if (item.id === 'How to Train Your Dragon') {
                window.location.href = '/Home/HowtoTrainYourDragon';
            } else if (item.id === 'StrangerThings') {
                window.location.href = '/Home/StrangerThings';
            } else if (item.id === 'TheLastofUs') {
                window.location.href = '/Home/TheLastofUs';
            } else if (item.id === 'IronHeart') {
                window.location.href = '/Home/IronHeart';
            } else if (item.id === 'How to Train Your Dragon') {
                window.location.href = '/Home/HowtoTrainYourDragon';
            } else if (item.id === 'How to Train Your Dragon') {
                window.location.href = '/Home/HowtoTrainYourDragon';
            } else {
                window.location.href = '/Home';
            }
        });
    }
    // Click-to-play for songs
    else if (item.video) {
        card.addEventListener('click', (e) => {
            if (e.target.classList.contains('card-badge')) return;
            const videoId = getYouTubeId(item.video);
            if (!videoId) return;

            const modal = document.getElementById('video-modal');
            const iframe = document.getElementById('video-iframe');
            iframe.src = `https://www.youtube.com/embed/${videoId}?autoplay=1&rel=0&modestbranding=1`;
            modal.classList.add('show');
            document.body.style.overflow = 'hidden';
        });
    }

    // Hover preview for songs
    if (item.video && (sectionId === 'new-songs' || sectionId === 'trending-songs')) {
        let hoverTimer;
        const videoPreview = card.querySelector('.video-preview');

        card.addEventListener('mouseenter', () => {
            const videoId = getYouTubeId(item.video);
            if (!videoId) return;

            hoverTimer = setTimeout(() => {
                videoPreview.innerHTML = `
                    <iframe 
                        src="https://www.youtube.com/embed/${videoId}?autoplay=1&mute=1&controls=0&loop=1&playlist=${videoId}" 
                        frameborder="0" 
                        allowfullscreen>
                    </iframe>
                `;
                videoPreview.classList.add('active');
            }, 1000);
        });

        card.addEventListener('mouseleave', () => {
            clearTimeout(hoverTimer);
            videoPreview.innerHTML = '';
            videoPreview.classList.remove('active');
        });
    }

    return card;
}

function createNotification(notification) {
    const notifElement = document.createElement('div');
    notifElement.className = 'notification';
    notifElement.innerHTML = `
        <div class="notification-icon">
            <i class="fas fa-bell"></i>
        </div>
        <div class="notification-content">
            <h4>${notification.title}</h4>
            <p>${notification.content}</p>
        </div>
        <div class="notification-close">
            <i class="fas fa-times"></i>
        </div>
    `;

    const closeBtn = notifElement.querySelector('.notification-close');
    closeBtn.addEventListener('click', () => {
        notifElement.classList.remove('show');
        setTimeout(() => notifElement.remove(), 300);
    });

    return notifElement;
}

function showNotification(notification) {
    const container = document.getElementById('notification-container');
    const notif = createNotification(notification);
    container.appendChild(notif);

    setTimeout(() => notif.classList.add('show'), 10);
    setTimeout(() => {
        notif.classList.remove('show');
        setTimeout(() => notif.remove(), 300);
    }, 5000);
}

document.addEventListener('DOMContentLoaded', function () {
    // Populate content sections
    for (const sectionId in contentData) {
        const section = document.getElementById(sectionId);
        if (section) {
            contentData[sectionId].forEach(item => {
                section.appendChild(createContentCard(item, sectionId));
            });
        }
    }

    // Video modal handling
    const videoModal = document.getElementById('video-modal');
    const videoIframe = document.getElementById('video-iframe');
    const closeModal = document.querySelector('.close-modal');

    function closeVideoModal() {
        videoIframe.src = '';
        videoModal.classList.remove('show');
        document.body.style.overflow = 'auto';
    }

    closeModal.addEventListener('click', closeVideoModal);
    videoModal.addEventListener('click', (e) => {
        if (e.target === videoModal) closeVideoModal();
    });

    document.addEventListener('keydown', (e) => {
        if (e.key === 'Escape' && videoModal.classList.contains('show')) {
            closeVideoModal();
        }
    });

    // Header scroll effect
    window.addEventListener('scroll', () => {
        const header = document.querySelector('.header');
        header.classList.toggle('scrolled', window.scrollY > 50);
    });

    // Search functionality
    const searchIcon = document.getElementById('search-icon');
    const searchBar = document.querySelector('.search-bar');
    searchIcon.addEventListener('click', () => {
        searchBar.classList.toggle('active');
        if (searchBar.classList.contains('active')) {
            searchBar.focus();
        }
    });

    // Profile dropdown
    const profile = document.getElementById('user-profile');
    const dropdown = document.querySelector('.profile-dropdown');
    profile.addEventListener('click', (e) => {
        e.stopPropagation();
        dropdown.classList.toggle('show');
    });

    document.addEventListener('click', () => {
        dropdown.classList.remove('show');
    });

    // Hero play button
    document.getElementById('play-button').addEventListener('click', () => {
        videoIframe.src = "https://www.youtube.com/embed/NBGHO2mkeBU?autoplay=1";
        videoModal.classList.add('show');
        document.body.style.overflow = 'hidden';
    });

    // Initial notifications
    setTimeout(() => showNotification(notifications[0]), 2000);
    setTimeout(() => showNotification(notifications[1]), 5000);
});

setInterval(() => {
    if (Math.random() > 0.7) {
        const randomNotif = notifications[Math.floor(Math.random() * notifications.length)];
        showNotification(randomNotif);
    }
}, 15000);