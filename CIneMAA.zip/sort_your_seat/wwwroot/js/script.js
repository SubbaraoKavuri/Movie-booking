﻿// Movie Card Filter Based on Search Input
document.addEventListener("DOMContentLoaded", function () {
    const searchInput = document.querySelector(".search-box input");
    const movieCards = document.querySelectorAll(".card");

    searchInput.addEventListener("input", function () {
        const searchTerm = this.value.toLowerCase();

        movieCards.forEach(card => {
            const title = card.dataset.title.toLowerCase();
            if (title.includes(searchTerm)) {
                card.style.display = "block";
            } else {
                card.style.display = "none";
            }
        });
    });
});
