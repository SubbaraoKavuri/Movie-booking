﻿document.addEventListener('DOMContentLoaded', function () {
    // Mobile Menu Toggle
    const menuToggle = document.createElement('button');
    menuToggle.className = 'menu-toggle';
    menuToggle.innerHTML = '<i class="fas fa-bars"></i>';
    document.body.appendChild(menuToggle);

    const nav = document.querySelector('nav');
    const sidePanel = document.querySelector('.side-panel');

    menuToggle.addEventListener('click', function () {
        nav.classList.toggle('active');
    });

    // Navigation Sidebar Toggle
    const navToggle = document.createElement('button');
    navToggle.className = 'nav-toggle';
    navToggle.innerHTML = '<i class="fas fa-chevron-left"></i>';
    nav.appendChild(navToggle);

    navToggle.addEventListener('click', function (e) {
        e.stopPropagation();
        nav.classList.toggle('collapsed');
        this.querySelector('i').classList.toggle('fa-chevron-left');
        this.querySelector('i').classList.toggle('fa-chevron-right');
    });

    // Side Panel Toggle
    const panelToggle = document.createElement('button');
    panelToggle.className = 'panel-toggle';
    panelToggle.innerHTML = '<i class="fas fa-chevron-right"></i>';
    sidePanel.appendChild(panelToggle);

    panelToggle.addEventListener('click', function (e) {
        e.stopPropagation();
        sidePanel.classList.toggle('collapsed');
        this.querySelector('i').classList.toggle('fa-chevron-left');
        this.querySelector('i').classList.toggle('fa-chevron-right');
    });

    // Close panels when clicking outside on mobile
    document.addEventListener('click', function (e) {
        if (window.innerWidth <= 1200) {
            if (!nav.contains(e.target) && e.target !== menuToggle) {
                nav.classList.remove('active');
            }
            if (!sidePanel.contains(e.target)) {
                sidePanel.classList.remove('active');
            }
        }
    });

    // Carousel Functionality
    const carousel = document.querySelector('.carousel');
    if (carousel) {
        const slides = document.querySelectorAll('.carousel-slide');
        let currentSlide = 0;
        let slideInterval;

        function showSlide(n) {
            slides.forEach(slide => slide.classList.remove('active'));
            currentSlide = (n + slides.length) % slides.length;
            slides[currentSlide].classList.add('active');
        }

        function nextSlide() {
            showSlide(currentSlide + 1);
        }

        // Auto-advance every 5 seconds
        function startSlideShow() {
            slideInterval = setInterval(nextSlide, 5000);
        }

        // Initialize
        showSlide(0);
        startSlideShow();

        // Pause on hover
        carousel.addEventListener('mouseenter', () => {
            clearInterval(slideInterval);
        });

        carousel.addEventListener('mouseleave', startSlideShow);

        // Manual navigation
        document.querySelector('.carousel-arrow.left')?.addEventListener('click', () => {
            clearInterval(slideInterval);
            showSlide(currentSlide - 1);
            startSlideShow();
        });

        document.querySelector('.carousel-arrow.right')?.addEventListener('click', () => {
            clearInterval(slideInterval);
            showSlide(currentSlide + 1);
            startSlideShow();
        });
    }

    // Search Functionality
    const searchBar = document.querySelector('.search-bar');
    if (searchBar) {
        searchBar.addEventListener('keypress', function (e) {
            if (e.key === 'Enter') {
                performSearch(this.value);
            }
        });

        function performSearch(query) {
            console.log('Searching for:', query);
            // Implement actual search functionality here
        }
    }

    // Card hover effects
    document.querySelectorAll('.card').forEach(card => {
        card.addEventListener('mouseenter', function () {
            this.style.transform = 'translateY(-5px)';
            this.style.boxShadow = '0 10px 20px rgba(0, 0, 0, 0.3)';
        });

        card.addEventListener('mouseleave', function () {
            this.style.transform = '';
            this.style.boxShadow = '';
        });
    });

    // Toggle side panel on mobile
    const sidePanelToggle = document.createElement('button');
    sidePanelToggle.className = 'side-panel-toggle';
    sidePanelToggle.innerHTML = '<i class="fas fa-film"></i>';
    document.body.appendChild(sidePanelToggle);

    sidePanelToggle.addEventListener('click', function () {
        sidePanel.classList.toggle('active');
    });
});