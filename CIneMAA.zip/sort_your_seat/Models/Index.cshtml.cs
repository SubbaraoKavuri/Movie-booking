﻿using Microsoft.AspNetCore.Mvc.RazorPages;

namespace sort_your_seat.Models
{
        public class IndexModel : PageModel
        {
            public void OnGet()
            {
                // You can add any logic here if needed
            }
    }
}
