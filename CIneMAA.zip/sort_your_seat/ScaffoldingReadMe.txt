﻿Support for ASP.NET Core Identity was added to your project.

