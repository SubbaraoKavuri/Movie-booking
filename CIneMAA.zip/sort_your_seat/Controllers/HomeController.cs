using System.Diagnostics;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using sort_your_seat.Models;

namespace sort_your_seat.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;

        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }

        public IActionResult Index()
        {
            return View();
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [Authorize]
        public IActionResult Home()
        {
            return View();
        }

        public IActionResult Songs()
        {
            return View();
        }

        public IActionResult F1TheMovie()
        {
            return View();
        }

        public IActionResult Junior2025()
        {
            return View();
        }
        public IActionResult Superman()
        {
            return View();
        }
        public IActionResult JurassicWorldRebirth()
        {
            return View();
        }

        public IActionResult Saiyaara()
        {
            return View();
        }
        public IActionResult HowtoTrainYourDragon()
        {
            return View();
        }
        public IActionResult StrangerThings()
        {
            return View();
        }
        public IActionResult TheLastofUs()
        {
            return View();
        }
        public IActionResult IronHeart()
        {
            return View();
        }
        public IActionResult MoneyHeist()
        {
            return View();
        }
        public IActionResult Loki()
        {
            return View();
        }
        public IActionResult hariharaveeramallu()
        {
            return View();
        }
        public IActionResult AvatarFireandAsh()
        {
            return View();
        }
        public IActionResult TheFantasticFourFirstSteps()
        {
            return View();
        }
        public IActionResult MahavatarNarsimha()
        {
            return View();
        }
        public IActionResult War2()
        {
            return View();
        }
        public IActionResult Coolie()
        {
            return View();
        }



        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}